namespace Flexify.Models
{
    public class Cast
    {
        public string Name { get; set; }
    }
}