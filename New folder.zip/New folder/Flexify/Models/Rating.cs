namespace Flexify.Models
{
    public class Rating
    {
        public string Title { get; set; }
        public string Rate { get; set; }
    }
}